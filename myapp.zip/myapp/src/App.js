import './style.css';
import React from 'react';
import { BrowserRouter, Routes, Route } from 'react-router-dom';
import NavBar from './NavBar';
import Form from './Form';
import StudentsList from './StudentsList';

function App() {   
  return (
    <div className="App">
     <BrowserRouter>
      <NavBar />
      <Routes>
        <Route path="/" element={<Form />} />
        <Route path="/list" element={<StudentsList />} />
      </Routes>
     </BrowserRouter>
    </div>
  );
}

export default App;
